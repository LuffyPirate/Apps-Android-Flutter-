# Time Tracker Flutter Course

Source code for my Time Tracker Flutter Course on Udemy.

## Running the project with Firebase

This project uses the following package name (case sensitive):

- `com.codingwithflutter.timetrackerfluttercourse` on Android
- `com.codingwithflutter.timeTrackerFlutterCourse` on iOS

You can clone this repo and reuse this package name if you want, but you will need to register the project with your on Firebase account.

Once this is done, you can download the `ios/Runner/GoogleService-Info.plist` and `android/app/google-services.json` files from your Firebase project settings as needed.

Instructions for how to perform these steps are contained in the course.

### [License: MIT](LICENSE.md)

